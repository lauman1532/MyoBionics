var searchData=
[
  ['posetostring',['poseToString',['../group__utility__funcs.html#ga280b0dfc78d0609ac8e431f4b1764902',1,'MyoBridge']]],
  ['printconnectionstatus',['printConnectionStatus',['../print_firmware_info_8ino.html#a7bd552e2fe06672d581e53cee57b5097',1,'printFirmwareInfo.ino']]]
];
