var searchData=
[
  ['packet_5fbuffer_5fsize',['PACKET_BUFFER_SIZE',['../_myo_bridge_8h.html#ab30af815d6e9494361629440f14e3716',1,'MyoBridge.h']]],
  ['patch',['patch',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#ac34b55d7b945df27d348e323ae78b355',1,'MYOHW_PACKED']]],
  ['payload_5fsize',['payload_size',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3b40747df7a523ea7d9cfa15efcaff3a',1,'MYOHW_PACKED']]],
  ['pdata',['pData',['../struct_m_y_b_write_cmd__t.html#ac2ffc625cdd3a23cfd987d404ca47fa6',1,'MYBWriteCmd_t::pData()'],['../struct_m_y_b_data_rsp__t.html#a148e7d3567f30da277cfb0fd78a26755',1,'MYBDataRsp_t::pData()']]],
  ['pose',['pose',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#a518831828d6864f3b025422598e5a845',1,'MYOHW_PACKED::MYOHW_PACKED']]],
  ['posetostring',['poseToString',['../group__utility__funcs.html#ga280b0dfc78d0609ac8e431f4b1764902',1,'MyoBridge']]],
  ['printconnectionstatus',['printConnectionStatus',['../print_firmware_info_8ino.html#a7bd552e2fe06672d581e53cee57b5097',1,'printFirmwareInfo.ino']]],
  ['printfirmwareinfo_2eino',['printFirmwareInfo.ino',['../print_firmware_info_8ino.html',1,'']]]
];
