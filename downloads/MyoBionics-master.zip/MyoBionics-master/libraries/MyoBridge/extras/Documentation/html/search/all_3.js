var searchData=
[
  ['devicename',['DeviceName',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1aaacec5de803529515f571288cec049e1',1,'myohw.h']]],
  ['disableallmessages',['disableAllMessages',['../group__advanced__funcs.html#ga1d5259d0651474d18909eb2f5c24b36b',1,'MyoBridge']]],
  ['disableposedata',['disablePoseData',['../group__basic__funcs.html#gada461094adb8f2aa68bd29476b533c6c',1,'MyoBridge']]],
  ['disablesleep',['disableSleep',['../group__basic__funcs.html#gac67b7cf02b451c5bc94dccc3730a404d',1,'MyoBridge']]],
  ['doconfirmedwrite',['doConfirmedWrite',['../group__advanced__funcs.html#gaea589b1f77b598db320ca0c24bf42ecb',1,'MyoBridge']]],
  ['dopersistentread',['doPersistentRead',['../group__advanced__funcs.html#gaeb246fdfa656de14bd345d80762f54eb',1,'MyoBridge']]],
  ['duration',['duration',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#a3739e87809df3ba04c61caa5e7485626',1,'MYOHW_PACKED::MYOHW_PACKED']]]
];
