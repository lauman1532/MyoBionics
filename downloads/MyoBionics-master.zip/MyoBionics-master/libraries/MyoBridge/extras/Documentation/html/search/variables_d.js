var searchData=
[
  ['sample1',['sample1',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a5e856ee4084de31a0a5b3a79ae2ddc2c',1,'MYOHW_PACKED']]],
  ['sample2',['sample2',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a54cee94f4078855a841d86721ce2b97d',1,'MYOHW_PACKED']]],
  ['serial_5fnumber',['serial_number',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a4677b6821eb7fce53294d0fa02cd3b74',1,'MYOHW_PACKED']]],
  ['sku',['sku',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a74dc077e9a8d8404b8651b6fd23e665b',1,'MYOHW_PACKED']]],
  ['sleep_5fmode',['sleep_mode',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#abff3bb813c386f445df61694b66f458b',1,'MYOHW_PACKED']]],
  ['status',['status',['../struct_m_y_b_async_status_cmd__t.html#a474263276ca4a2137e2b70edb5e627bd',1,'MYBAsyncStatusCmd_t::status()'],['../struct_m_y_b_status_rsp__t.html#a9e77fcc606195fd193673b676566397b',1,'MYBStatusRsp_t::status()']]],
  ['steps',['steps',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a1b038c4bca9432562b1459387f7b3798',1,'MYOHW_PACKED']]],
  ['stream_5findicating',['stream_indicating',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a7ddb3ee20bde3aa6a37bbeee8006f04e',1,'MYOHW_PACKED']]],
  ['strength',['strength',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#a9c72e0e5a73bbefc184292822a619e4d',1,'MYOHW_PACKED::MYOHW_PACKED']]],
  ['sync_5fresult',['sync_result',['../struct_m_y_o_h_w___p_a_c_k_e_d_1_1_m_y_o_h_w___p_a_c_k_e_d.html#a7b8dbe04777d44aa62f86111cef16e13',1,'MYOHW_PACKED::MYOHW_PACKED']]]
];
