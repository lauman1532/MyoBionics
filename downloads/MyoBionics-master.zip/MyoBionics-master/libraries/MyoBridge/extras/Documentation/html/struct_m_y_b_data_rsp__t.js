var struct_m_y_b_data_rsp__t =
[
    [ "characteristic", "struct_m_y_b_data_rsp__t.html#a4a8bbe850d15fae3c6e75987b1526c18", null ],
    [ "hdr", "struct_m_y_b_data_rsp__t.html#a210a198292fd2d89d324ad43825aad11", null ],
    [ "pData", "struct_m_y_b_data_rsp__t.html#a148e7d3567f30da277cfb0fd78a26755", null ]
];