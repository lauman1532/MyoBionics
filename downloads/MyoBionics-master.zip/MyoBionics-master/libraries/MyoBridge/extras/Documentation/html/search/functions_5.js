var searchData=
[
  ['handleemgdata',['handleEMGData',['../read_e_m_g_data_8ino.html#a23f64e6569cdfa4d345ba99640ea1049',1,'readEMGData.ino']]],
  ['handleimudata',['handleIMUData',['../read_i_m_u_data_8ino.html#a7cbc2550758166a7edf6943e19b3c29d',1,'readIMUData.ino']]],
  ['handleposedata',['handlePoseData',['../read_pose_data_8ino.html#ab74e35744072189cef0b760a2dfd1bc2',1,'readPoseData.ino']]]
];
