var searchData=
[
  ['characteristic',['characteristic',['../struct_m_y_b_data_rsp__t.html#a4a8bbe850d15fae3c6e75987b1526c18',1,'MYBDataRsp_t']]],
  ['classifier_5fmode',['classifier_mode',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3720af69d3661e9dc477d7d2cc24bf6d',1,'MYOHW_PACKED']]],
  ['classifiereventcharacteristic',['ClassifierEventCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ae308fd322e41ec31acc83595916ecbee',1,'myohw.h']]],
  ['classifierservice',['ClassifierService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867af65db57e3874d5c5b8446809d10f1cca',1,'myohw.h']]],
  ['cmd',['cmd',['../struct_m_y_b_cmd_hdr__t.html#a42c20dea1d757a87c1046ebd009ec488',1,'MYBCmdHdr_t']]],
  ['command',['command',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a14572e215430b5e44c4b92b1c7e1f1b3',1,'MYOHW_PACKED']]],
  ['commandcharacteristic',['CommandCharacteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867adf8a8c3c0522f4cd9a4821600b1744b1',1,'myohw.h']]],
  ['conn_5fstatus_5fbridge_5fsetup',['CONN_STATUS_BRIDGE_SETUP',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522acab5545b433b7e2cecea8f36e4c60cd6',1,'MyoBridge.h']]],
  ['conn_5fstatus_5fconnecting',['CONN_STATUS_CONNECTING',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522a9202b0dc4e01744bc15da3014ece5f7a',1,'MyoBridge.h']]],
  ['conn_5fstatus_5fdiscovering',['CONN_STATUS_DISCOVERING',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522afa77d63ef667572f6e0446d351f3b4c0',1,'MyoBridge.h']]],
  ['conn_5fstatus_5finit',['CONN_STATUS_INIT',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522aab262cf8ca1185d9b87787073edf8698',1,'MyoBridge.h']]],
  ['conn_5fstatus_5flost',['CONN_STATUS_LOST',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522a5dbc4ce1e19d36050d0bd19d1ee4e0fd',1,'MyoBridge.h']]],
  ['conn_5fstatus_5fready',['CONN_STATUS_READY',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522a351770c387a9606bbde492f93eb795ec',1,'MyoBridge.h']]],
  ['conn_5fstatus_5fscanning',['CONN_STATUS_SCANNING',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522a76269105343e89eb2c909f6ee1787034',1,'MyoBridge.h']]],
  ['conn_5fstatus_5funknown',['CONN_STATUS_UNKNOWN',['../_myo_bridge_8h.html#aaf88bddfc01bb3cb9ccf3077b1da5522a5f3761a8396f01bdcacb45623dba35ed',1,'MyoBridge.h']]],
  ['connectionstatustostring',['connectionStatusToString',['../group__utility__funcs.html#gacba3fc3a629cfe244feff21f521bff00',1,'MyoBridge']]],
  ['controlservice',['ControlService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ad33871e3d686667c50ab78c9d8ea961c',1,'myohw.h']]],
  ['control_20commands',['Control Commands',['../group__myohw__control__commands.html',1,'']]]
];
