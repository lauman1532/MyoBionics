var searchData=
[
  ['reserved',['reserved',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3afb60b69f8c65d93172f4162be09908',1,'MYOHW_PACKED']]]
];
