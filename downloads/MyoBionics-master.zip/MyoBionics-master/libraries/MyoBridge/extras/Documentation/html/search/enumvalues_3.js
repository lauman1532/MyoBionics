var searchData=
[
  ['emg_5fmode_5fnone',['EMG_MODE_NONE',['../_myo_bridge_8h.html#ac6f991d21a293b773c554e8ad659885fa150f89f9b7bdfa8b34b3e144adb6f6ef',1,'MyoBridge.h']]],
  ['emg_5fmode_5fraw',['EMG_MODE_RAW',['../_myo_bridge_8h.html#ac6f991d21a293b773c554e8ad659885fa239bc379c7d181b3710f0647f0dc26fa',1,'MyoBridge.h']]],
  ['emg_5fmode_5fsend',['EMG_MODE_SEND',['../_myo_bridge_8h.html#ac6f991d21a293b773c554e8ad659885faef9f5b238f86d1b034fe05b54d007a5b',1,'MyoBridge.h']]],
  ['emgdata0characteristic',['EmgData0Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a57f16df1d88f45b6406b0dae9c3ddb1b',1,'myohw.h']]],
  ['emgdata1characteristic',['EmgData1Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ae57e38c1aec0d35761112ced6b94aaeb',1,'myohw.h']]],
  ['emgdata2characteristic',['EmgData2Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867ad3602d06599cad282167ab2fc7d8b2a4',1,'myohw.h']]],
  ['emgdata3characteristic',['EmgData3Characteristic',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a37df066d48684b2e68cee256a173da24',1,'myohw.h']]],
  ['emgdataservice',['EmgDataService',['../group__myo__hardware.html#gga39811b63b77dda16ed982f292f034867a24616741af7080cf11b541e1f72212e8',1,'myohw.h']]],
  ['err_5finvalid_5fpacket',['ERR_INVALID_PACKET',['../_myo_bridge_8h.html#aa37476b945410b138d2a66c88ededf26a36e0745b01cab96525b0d51f9b7109ae',1,'MyoBridge.h']]],
  ['err_5fno_5fpacket',['ERR_NO_PACKET',['../_myo_bridge_8h.html#aa37476b945410b138d2a66c88ededf26a2573d9bef98f9d6ddef12282caf0f81a',1,'MyoBridge.h']]],
  ['err_5frx_5fbuffer_5foverflow',['ERR_RX_BUFFER_OVERFLOW',['../_myo_bridge_8h.html#aa37476b945410b138d2a66c88ededf26a50df5b222ca3dddb60e8df0174be3ccd',1,'MyoBridge.h']]]
];
