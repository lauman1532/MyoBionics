var searchData=
[
  ['characteristic',['characteristic',['../struct_m_y_b_data_rsp__t.html#a4a8bbe850d15fae3c6e75987b1526c18',1,'MYBDataRsp_t']]],
  ['classifier_5fmode',['classifier_mode',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3720af69d3661e9dc477d7d2cc24bf6d',1,'MYOHW_PACKED']]],
  ['cmd',['cmd',['../struct_m_y_b_cmd_hdr__t.html#a42c20dea1d757a87c1046ebd009ec488',1,'MYBCmdHdr_t']]],
  ['command',['command',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a14572e215430b5e44c4b92b1c7e1f1b3',1,'MYOHW_PACKED']]]
];
