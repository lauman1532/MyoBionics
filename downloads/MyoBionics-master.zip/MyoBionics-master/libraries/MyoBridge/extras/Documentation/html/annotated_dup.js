var annotated_dup =
[
    [ "MYBAsyncStatusCmd_t", "struct_m_y_b_async_status_cmd__t.html", "struct_m_y_b_async_status_cmd__t" ],
    [ "MYBCmdHdr_t", "struct_m_y_b_cmd_hdr__t.html", "struct_m_y_b_cmd_hdr__t" ],
    [ "MYBDataRsp_t", "struct_m_y_b_data_rsp__t.html", "struct_m_y_b_data_rsp__t" ],
    [ "MYBGetStatusCmd_t", "struct_m_y_b_get_status_cmd__t.html", "struct_m_y_b_get_status_cmd__t" ],
    [ "MYBPingCmd_t", "struct_m_y_b_ping_cmd__t.html", "struct_m_y_b_ping_cmd__t" ],
    [ "MYBPingRsp_t", "struct_m_y_b_ping_rsp__t.html", "struct_m_y_b_ping_rsp__t" ],
    [ "MYBReadCmd_t", "struct_m_y_b_read_cmd__t.html", "struct_m_y_b_read_cmd__t" ],
    [ "MYBRspHdr_t", "struct_m_y_b_rsp_hdr__t.html", "struct_m_y_b_rsp_hdr__t" ],
    [ "MYBStatusRsp_t", "struct_m_y_b_status_rsp__t.html", "struct_m_y_b_status_rsp__t" ],
    [ "MYBWriteCmd_t", "struct_m_y_b_write_cmd__t.html", "struct_m_y_b_write_cmd__t" ],
    [ "MyoBridge", "class_myo_bridge.html", "class_myo_bridge" ],
    [ "MYOHW_PACKED", "struct_m_y_o_h_w___p_a_c_k_e_d.html", "struct_m_y_o_h_w___p_a_c_k_e_d" ]
];