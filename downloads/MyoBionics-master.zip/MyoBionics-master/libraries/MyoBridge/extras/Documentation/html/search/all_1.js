var searchData=
[
  ['batterylevelcharacteristic',['BatteryLevelCharacteristic',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a5dc0cfdfaa7817966f1e86aa36bf5670',1,'myohw.h']]],
  ['batteryservice',['BatteryService',['../group__myo__hardware.html#gga8912ee438db4275967233a844a8c36f1a3c3085f75abeb351af41db8bb8c93e26',1,'myohw.h']]],
  ['begin',['begin',['../group__basic__funcs.html#ga362caf3b69a6979cd4e8ec4f7ed7fcd8',1,'MyoBridge']]],
  ['bridge',['bridge',['../print_firmware_info_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;printFirmwareInfo.ino'],['../read_e_m_g_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readEMGData.ino'],['../read_i_m_u_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readIMUData.ino'],['../read_pose_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0',1,'bridge():&#160;readPoseData.ino']]],
  ['bridgeserial',['bridgeSerial',['../print_firmware_info_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;printFirmwareInfo.ino'],['../read_e_m_g_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readEMGData.ino'],['../read_i_m_u_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readIMUData.ino'],['../read_pose_data_8ino.html#ad9fb93a907416d9117978fb354112691',1,'bridgeSerial(2, 3):&#160;readPoseData.ino']]]
];
