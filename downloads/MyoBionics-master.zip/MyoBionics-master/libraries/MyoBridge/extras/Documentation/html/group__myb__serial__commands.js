var group__myb__serial__commands =
[
    [ "MYB_CMD_GET_STATUS", "group__myb__serial__commands.html#ga919db4d95c13d47e38f43190016de7da", null ],
    [ "MYB_CMD_PING", "group__myb__serial__commands.html#ga6f53fde2665b05b2748576296f15cb8b", null ],
    [ "MYB_CMD_READ_CHAR", "group__myb__serial__commands.html#ga1675e35c97539c3c8c817f1369ca81d7", null ],
    [ "MYB_CMD_SET_ASYNC_STATUS", "group__myb__serial__commands.html#ga3a1484cf9807d38ac5ba324720155647", null ],
    [ "MYB_CMD_WRITE_CHAR", "group__myb__serial__commands.html#ga83095f5a0c3bd1553a2186467c250f02", null ]
];