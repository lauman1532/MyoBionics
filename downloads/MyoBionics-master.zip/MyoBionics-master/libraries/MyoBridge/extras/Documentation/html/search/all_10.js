var searchData=
[
  ['unlock_5fpose',['unlock_pose',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a007f6cbf424c09fbec6d1eab769c6250',1,'MYOHW_PACKED']]],
  ['unlockmyo',['unlockMyo',['../group__basic__funcs.html#gacf21fbfe35625c9b782dc890952d557e',1,'MyoBridge']]],
  ['update',['update',['../group__basic__funcs.html#ga085f3de45bc0667ea7263274874713ca',1,'MyoBridge']]],
  ['utility_20functions',['Utility Functions',['../group__utility__funcs.html',1,'']]]
];
