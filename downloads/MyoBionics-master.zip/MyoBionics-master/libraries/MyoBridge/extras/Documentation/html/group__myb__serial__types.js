var group__myb__serial__types =
[
    [ "MYB_RSP_PING", "group__myb__serial__types.html#ga68193d58db29516145d92b400f6fe1d7", null ],
    [ "MYB_RSP_STATUS", "group__myb__serial__types.html#gaac43e6c5670c29cfe4e438f6229fa6da", null ],
    [ "MYB_RSP_VALUE", "group__myb__serial__types.html#gab1b328efdcf130a1091ada29f77cfce4", null ]
];