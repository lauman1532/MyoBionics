var searchData=
[
  ['reademgdata_2eino',['readEMGData.ino',['../read_e_m_g_data_8ino.html',1,'']]],
  ['readimudata_2eino',['readIMUData.ino',['../read_i_m_u_data_8ino.html',1,'']]],
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readposedata_2eino',['readPoseData.ino',['../read_pose_data_8ino.html',1,'']]],
  ['reserved',['reserved',['../struct_m_y_o_h_w___p_a_c_k_e_d.html#a3afb60b69f8c65d93172f4162be09908',1,'MYOHW_PACKED']]],
  ['result_5fbuffer_5fsize',['RESULT_BUFFER_SIZE',['../_myo_bridge_8h.html#a4b89da90303d95ce654b7ad8a05daac9',1,'MyoBridge.h']]],
  ['rx_5fbuffer_5fsize',['RX_BUFFER_SIZE',['../_myo_bridge_8h.html#a739a2a1a0047c98ac1b18ecd25dac092',1,'MyoBridge.h']]]
];
