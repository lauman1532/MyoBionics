var group__callback__funcs =
[
    [ "setEMGDataCallBack", "group__callback__funcs.html#gab321a2fe2fc598fdc4b9c12a6cf8d100", null ],
    [ "setIMUDataCallBack", "group__callback__funcs.html#ga03b432c626750b5a9c001c57537aba3b", null ],
    [ "setIMUMotionCallBack", "group__callback__funcs.html#ga2b3d5fa3fcde7b8095aa66aad87ea1f3", null ],
    [ "setPoseEventCallBack", "group__callback__funcs.html#gac7feb1c5978e1f7064b879f60fcead6f", null ]
];