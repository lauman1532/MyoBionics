var searchData=
[
  ['enableallmessages',['enableAllMessages',['../group__advanced__funcs.html#ga52ae472dcf995d2806e7eb190f4b214b',1,'MyoBridge']]],
  ['enableposedata',['enablePoseData',['../group__basic__funcs.html#ga619d927ea7aca5333685717869db2f0d',1,'MyoBridge']]],
  ['enablesleep',['enableSleep',['../group__basic__funcs.html#gae9f63a6013004c894fe365343933ba61',1,'MyoBridge']]]
];
