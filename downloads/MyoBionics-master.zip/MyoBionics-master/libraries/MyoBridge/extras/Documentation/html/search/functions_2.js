var searchData=
[
  ['disableallmessages',['disableAllMessages',['../group__advanced__funcs.html#ga1d5259d0651474d18909eb2f5c24b36b',1,'MyoBridge']]],
  ['disableposedata',['disablePoseData',['../group__basic__funcs.html#gada461094adb8f2aa68bd29476b533c6c',1,'MyoBridge']]],
  ['disablesleep',['disableSleep',['../group__basic__funcs.html#gac67b7cf02b451c5bc94dccc3730a404d',1,'MyoBridge']]],
  ['doconfirmedwrite',['doConfirmedWrite',['../group__advanced__funcs.html#gaea589b1f77b598db320ca0c24bf42ecb',1,'MyoBridge']]],
  ['dopersistentread',['doPersistentRead',['../group__advanced__funcs.html#gaeb246fdfa656de14bd345d80762f54eb',1,'MyoBridge']]]
];
