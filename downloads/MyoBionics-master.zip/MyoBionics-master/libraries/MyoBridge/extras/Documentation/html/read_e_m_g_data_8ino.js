var read_e_m_g_data_8ino =
[
    [ "bridgeSerial", "read_e_m_g_data_8ino.html#ad9fb93a907416d9117978fb354112691", null ],
    [ "handleEMGData", "read_e_m_g_data_8ino.html#a23f64e6569cdfa4d345ba99640ea1049", null ],
    [ "loop", "read_e_m_g_data_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "read_e_m_g_data_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "bridge", "read_e_m_g_data_8ino.html#a1bbd37be74a749453817a3d174cd31b0", null ]
];